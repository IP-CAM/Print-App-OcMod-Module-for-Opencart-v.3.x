<?php
// Heading
$_['heading_title']       = 'Print.App';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified Print.App Module!';

// Entry
$_['api_label']          = 'Domain Key:';
$_['secret_label']        = 'Auth Key:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module Print.App!';
$_['error_code']          = 'Code Required';
?>